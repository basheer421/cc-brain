import os
import sys
import fcntl

lock_path = os.path.expanduser("~/.cc-brain/.lock")
os.makedirs(os.path.dirname(lock_path), exist_ok=True)
lock_file = open(lock_path, "w")
try:
    fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
except OSError:
    sys.exit(0)

resources = os.path.join(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, resources)

import cc_brain.app as app
from pathlib import Path
app.ICONS_DIR = Path(resources) / "icons"

from cc_brain.app import main
main()
